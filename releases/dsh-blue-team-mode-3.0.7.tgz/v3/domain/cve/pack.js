/**
 * 2026 CVE 防御包。
 *
 * 说明：条目按用户提供的 CVE 描述建模，未联网核验具体受影响版本与补丁号。
 * 这里只给补丁优先级、缓解动作和启发式日志特征，不包含利用代码。
 */

export const CVE_PACK_SCHEMA = 'blue-cve-pack/2026.11'

export const CVE_PACK = [
  {
    id: 'CVE-2026-111497',
    title: 'Node.js Brotli 解码器越界写 RCE',
    product: 'Node.js',
    type: 'rce',
    severity: 'critical',
    urgency: '立即',
    summary: 'Brotli 解码路径存在越界写，可通过压缩请求或依赖链触发，影响暴露的 Node.js Web 服务。',
    actions: [
      '升级到厂商确认修复的 Node.js 版本；不要只依赖应用层过滤。',
      '对 brotliDecompress 设置 maxOutputLength，并限制请求体大小、并发和超时。',
      '在反向代理层限制 Content-Encoding: br 的请求体大小；非必要不接受压缩上传。',
      '排查依赖链中自带 Brotli 解压的组件，按同一补丁级别升级。',
    ],
    patterns: [
      { id: 'node-brotli-compressed-body', label: 'Brotli 压缩请求体', regex: 'content-encoding\\s*:\\s*br', severity: 'low' },
      { id: 'node-brotli-huge-body', label: '异常大压缩请求', regex: '(content-length|body).{0,40}(?:[1-9]\\d{7,}|[5-9]\\d{6})', severity: 'medium' },
    ],
  },
  {
    id: 'CVE-2026-109618',
    title: 'PHP 核心层无认证 RCE（PHP2Shell）',
    product: 'PHP',
    type: 'rce',
    severity: 'critical',
    urgency: '立即',
    summary: 'PHP 核心层无认证路径可导致远程代码执行，影响面大，已有在野利用报告。',
    actions: [
      '升级 PHP 到修复版本；无法升级时先下线外部 CGI/FPM 暴露面。',
      '禁用 allow_url_include、auto_prepend_file、auto_append_file，收紧 open_basedir。',
      '限制上传目录不可执行，禁止 .php/.phtml/.phar 作为上传扩展。',
      '检查 access log 中的 PHP-CGI、php://input、auto_prepend_file 和异常 POST。',
    ],
    patterns: [
      { id: 'php-cgi-query', label: 'PHP-CGI 查询串', regex: '(?:php-cgi|php\\/cgi|%2fbin%2f|/cgi-bin/)', severity: 'high' },
      { id: 'php-prepend', label: 'PHP 自动前置文件', regex: '(?:auto_prepend_file|auto_append_file|allow_url_include)', severity: 'high' },
      { id: 'php-input', label: 'php://input 直接读取', regex: 'php://(?:input|filter)', severity: 'medium' },
      { id: 'php-exec-upload', label: '上传目录执行 PHP', regex: '(?:/uploads?/|/tmp/|\\\\Temp\\\\)[^\\s]{0,120}\\.(?:php|phtml|phar)', severity: 'high' },
    ],
  },
  {
    id: 'CVE-2026-109619',
    title: 'PHP 核心层无认证 RCE（PHP2Shell 关联）',
    product: 'PHP',
    type: 'rce',
    severity: 'critical',
    urgency: '立即',
    summary: '与 PHP2Shell 同批的核心层无认证 RCE，利用条件与 109618 类似。',
    actions: [
      '按 PHP2Shell 同一补丁级别升级 PHP。',
      '临时缓解：关闭外部不需要的 FPM/CGI 入口，限制管理面来源。',
      '检查 PHP 进程异常子进程、临时目录可执行文件和 webshell。',
    ],
    patterns: [
      { id: 'php2shell-shell', label: 'PHP 进程拉起 shell', regex: '(?:php|php-fpm).{0,80}(?:/bin/(?:ba)?sh|cmd\\.exe|powershell)', severity: 'high' },
      { id: 'php-webshell-tmp', label: '临时目录 PHP 文件', regex: '(?:/tmp/|\\\\Temp\\\\).{0,80}\\.(?:php|phtml)', severity: 'high' },
    ],
  },
  {
    id: 'CVE-2026-115560',
    title: 'PHP 未公开窄范围 RCE（PHP2Shell 系列）',
    product: 'PHP',
    type: 'rce',
    severity: 'high',
    urgency: '尽快',
    summary: '细节未完全公开，仅影响特定 PHP 扩展场景；不能因为“窄范围”而跳过补丁。',
    actions: [
      '盘点 PHP 扩展，移除不需要的扩展，尤其是会解析外部数据的扩展。',
      '跟进厂商公告；在补丁前限制受影响扩展的输入来源。',
      '对 PHP 错误日志和子进程创建做异常检测。',
    ],
    patterns: [
      { id: 'php-extension-load', label: '动态加载 PHP 扩展', regex: '(?:dl\\(|extension_dir|zend_extension)', severity: 'medium' },
    ],
  },
  {
    id: 'CVE-2026-48019',
    title: 'Laravel / Symfony Mime 组件 CRLF 注入',
    product: 'Laravel/Symfony',
    type: 'header-injection',
    severity: 'high',
    urgency: '尽快',
    summary: '邮件接口的地址/主题字段可注入 CRLF，造成恶意邮件头、密送或邮件服务滥用。',
    actions: [
      '升级 symfony/mime 与 Laravel 框架到修复版本。',
      '所有邮件地址、主题、显示名在进入 Mime 前拒绝 \\r、\\n、%0d、%0a。',
      '不要允许用户控制 Bcc/Cc/Reply-To；地址使用严格解析器。',
      '对忘记密码等接口做速率限制和邮件头异常告警。',
    ],
    patterns: [
      { id: 'mime-crlf', label: '邮件字段 CRLF 注入', regex: '(?:%0d|%0a|\\\\r|\\\\n).{0,60}(?:bcc|cc|reply-to|from|subject)', severity: 'high' },
      { id: 'mime-bcc', label: '用户可控 Bcc/Cc', regex: '(?:bcc|cc)\\s*[:=]\\s*[^\\s,;]+', severity: 'medium' },
    ],
  },
  {
    id: 'CVE-2026-93952',
    title: 'Arista VeloCloud Orchestrator SQL 注入',
    product: 'Arista VeloCloud',
    type: 'sqli',
    severity: 'critical',
    urgency: 'KEV 截止 2026-10-26（已过，立即）',
    summary: '可远程获取特权访问，已被 CISA 列入 KEV；管理面暴露是主要风险。',
    actions: [
      '按厂商公告升级 VeloCloud Orchestrator，优先于其他低风险变更。',
      '管理面禁止公网访问；只允许受控运维网段并加 MFA。',
      '在 WAF/反向代理层阻断 SQLi 关键字组合，但不要把它当唯一修复。',
      '轮换管理员凭据，检查异常登录和配置变更。',
    ],
    patterns: [
      { id: 'sqli-union', label: 'UNION SELECT 注入', regex: '(?:union\\s+(?:all\\s+)?select|information_schema|sleep\\s*\\(|benchmark\\s*\\()', severity: 'high' },
      { id: 'sqli-boolean', label: '布尔/报错注入', regex: '(?:\\bor\\b|\\band\\b)\\s+[\\d\'"]+\\s*=\\s*[\\d\'"]+', severity: 'medium' },
    ],
  },
  {
    id: 'CVE-2026-109390',
    title: 'AnyDesk Linux 预认证堆溢出',
    product: 'AnyDesk',
    type: 'rce',
    severity: 'high',
    urgency: '尽快',
    summary: '预认证堆溢出可导致远程代码执行，影响企业远程运维入口。',
    actions: [
      '升级 AnyDesk Linux 客户端/服务端到修复版本。',
      '禁止 AnyDesk 端口直接暴露公网；只允许受控中继或 VPN。',
      '限制无人值守访问，启用白名单和强口令/MFA。',
      '监控异常 AnyDesk 进程、连接和更新行为。',
    ],
    patterns: [
      { id: 'anydesk-port', label: 'AnyDesk 连接', regex: '(?:anydesk|:7070\\b|\\b7070\\b)', severity: 'low' },
    ],
  },
  {
    id: 'CVE-2026-111357',
    title: 'Ivanti Connect Secure 零日',
    product: 'Ivanti Connect Secure',
    type: 'auth-bypass',
    severity: 'critical',
    urgency: '立即',
    summary: '已被在野利用，可绕过身份认证接管 VPN 网关。',
    actions: [
      '按 Ivanti 公告升级/应用缓解措施；必要时先下线公网 VPN。',
      '重置本地管理员和 VPN 用户凭据，检查异常会话与配置。',
      '检查 /dana-na/、/dana/html5acc/ 等路径的异常请求。',
      '保留日志和内存证据，按入侵事件处理，不要只打补丁。',
    ],
    patterns: [
      { id: 'ivanti-dana', label: 'Ivanti dana-na 路径', regex: '/dana-(?:na|html5acc)/', severity: 'medium' },
      { id: 'ivanti-auth-bypass', label: 'VPN 认证绕过迹象', regex: '(?:ive|ivanti).{0,80}(?:bypass|unauth|admin)', severity: 'medium' },
    ],
  },
  {
    id: 'CVE-2026-118527',
    title: 'Ivanti Connect Secure 关联零日',
    product: 'Ivanti Connect Secure',
    type: 'auth-bypass',
    severity: 'critical',
    urgency: '立即',
    summary: '与 111357 同批的 Ivanti 零日，需按同一事件响应级别处理。',
    actions: [
      '与 111357 一并升级和排查，不单独判断“只中一个”。',
      '检查 VPN 网关的本地账户、计划任务、Web Shell 和外连。',
    ],
    patterns: [
      { id: 'ivanti-shell', label: 'Ivanti 目录异常脚本', regex: '/dana-na/.{0,80}\\.(?:jsp|jspx|war|php)', severity: 'high' },
    ],
  },
  {
    id: 'CVE-2026-102764',
    title: 'BeyondTrust 远程支持认证绕过',
    product: 'BeyondTrust',
    type: 'auth-bypass',
    severity: 'critical',
    urgency: '立即',
    summary: '无认证访问可被利用进入远程支持设备，已有企业被入侵报告。',
    actions: [
      '按厂商公告升级 BeyondTrust 远程支持设备。',
      '管理面和远程支持入口禁止公网直连；限制来源并启用 MFA。',
      '检查异常会话、账号创建、策略变更和文件传输。',
      '轮换 appliance 管理员和集成凭据。',
    ],
    patterns: [
      { id: 'beyondtrust-appliance', label: 'BeyondTrust 管理路径', regex: '(?:beyondtrust|bomgar).{0,120}(?:appliance|admin|session|api)', severity: 'medium' },
    ],
  },
  {
    id: 'CVE-2026-88771',
    title: 'NetScaler 入侵链漏洞（一）',
    product: 'Citrix NetScaler',
    type: 'exploit-chain',
    severity: 'critical',
    urgency: '立即',
    summary: '与 88779 组合利用可突破 Citrix 网关，获取内网入口。',
    actions: [
      '按 Citrix 公告升级 ADC/NetScaler，两个漏洞都必须修。',
      '管理面与 VPN 入口分离，限制公网管理访问。',
      '检查 /gwtan/、/vpn/ 路径和异常认证请求。',
      '轮换凭据，检查配置变更和会话。',
    ],
    patterns: [
      { id: 'netscaler-gwtan', label: 'NetScaler gwtan 路径', regex: '/(?:gwtan|vpn)/.{0,80}(?:netscaler|citrix|adc)', severity: 'medium' },
      { id: 'netscaler-vpn', label: 'NetScaler VPN 异常探测', regex: '(?:netscaler|citrix|adc).{0,80}(?:vpn|auth|bypass)', severity: 'medium' },
    ],
  },
  {
    id: 'CVE-2026-88779',
    title: 'NetScaler 入侵链漏洞（二）',
    product: 'Citrix NetScaler',
    type: 'exploit-chain',
    severity: 'critical',
    urgency: '立即',
    summary: '与 88771 组合利用的第二个漏洞；只修一个仍可能被链式突破。',
    actions: [
      '与 88771 同一维护窗口升级。',
      '在补丁前限制 VPN 入口，启用 WAF 和异常会话告警。',
      '检查 ns.conf、系统日志和外部连接。',
    ],
    patterns: [
      { id: 'netscaler-config', label: 'NetScaler 配置读取迹象', regex: '(?:ns\\.conf|/flash/nsconfig|/nsconfig/)', severity: 'high' },
    ],
  },
]

const BY_ID = new Map(CVE_PACK.map((item) => [item.id, item]))

export function listCves(filter = {}) {
  const query = String(filter.query || '').trim().toLowerCase()
  const product = String(filter.product || '').trim().toLowerCase()
  return CVE_PACK.filter((item) => {
    if (product !== '' && !item.product.toLowerCase().includes(product)) return false
    if (query !== '' && !(`${item.id} ${item.title} ${item.product} ${item.summary}`.toLowerCase().includes(query))) return false
    return true
  })
}

export function getCve(id) {
  return BY_ID.get(String(id || '').trim().toUpperCase()) || null
}

export function cveSummary() {
  const bySeverity = {}
  for (const item of CVE_PACK) bySeverity[item.severity] = (bySeverity[item.severity] || 0) + 1
  return { schema: CVE_PACK_SCHEMA, total: CVE_PACK.length, by_severity: bySeverity, verified: false }
}

export function scanCveText(text, options = {}) {
  const source = String(text || '')
  const maxHits = Math.min(Math.max(Number(options.maxHits) || 100, 1), 1000)
  const includeLow = options.includeLow === true
  const hits = []
  const weakHits = []
  for (const item of CVE_PACK) {
    for (const pattern of item.patterns) {
      let regex
      try { regex = new RegExp(pattern.regex, 'i') } catch { continue }
      const match = regex.exec(source)
      if (match === null) continue
      const hit = {
        cve: item.id,
        title: item.title,
        pattern: pattern.id,
        label: pattern.label,
        severity: pattern.severity,
        confidence: pattern.severity === 'low' ? 'low' : 'medium',
        match: match[0].slice(0, 200),
      }
      if (pattern.severity === 'low') {
        weakHits.push(hit)
        if (!includeLow) continue
      }
      hits.push(hit)
      if (hits.length >= maxHits) return { hits, weakHits, matched: hits.length > 0, truncated: true }
    }
  }
  return { hits, weakHits, matched: hits.length > 0, truncated: false }
}
